package Inicializacion;
public class Cliente extends Proveedor{
    private String tipo;
    
    //constructor
    public Cliente(String mes, String año, String codigo, String codPais, int llamComp, int llamInte, double totalPago) {
        super(mes, año, codigo, codPais, llamComp, llamInte, totalPago);
    }
  
    public Cliente(String codigo, String nombre, String direccion, String telefono, String tipo){
        super(codigo, nombre, direccion, telefono);
        this.tipo = tipo;
    }
       
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }   
}
