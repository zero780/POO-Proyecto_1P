package Metodos;
import Inicializacion.*;
import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Metodos_Varios {
    Scanner entrada = new Scanner(System.in);
    
    /*//VENTANA DE PRESENTACIÓN
    public int iniciarSistema(){
        int opcion = JOptionPane.showOptionDialog(null,"Seleccione una opcion", 
        "Bienvenido",
        JOptionPane.YES_NO_CANCEL_OPTION,
        JOptionPane.QUESTION_MESSAGE,
        null,    // null para icono por defecto.
        new Object[] { "Iniciar Sesión", "Salir"},   // null para YES, NO y CANCEL
        "opcion 1");
        return opcion;
    }*/
    
    //VERIFICAR EL INICIO DE SESIÓN
    public boolean verificarLogin(ArrayList<Usuario> userInfo, String usuario, String contraseña){
        boolean verificacion; int valor=0;
        for(Usuario p: userInfo){
            valor = 0;
            if (usuario.equals(p.getUsuario())){
                valor++;
            } if(contraseña.equals(p.getContraseña())){
                valor++;  
            } if(valor ==2){
                break;
            }
        }
        
        if(valor ==2){
            verificacion = true;
        }
        else {
            verificacion = false;
        }
        return verificacion;
    }
    
    //VERIFICAR SI UN DATO ES NUMÉRICO
    public boolean isNumeric(String cadena){
        try {
		Integer.parseInt(cadena);
		return true;
	} catch (NumberFormatException nfe){
		return false;
	}
    }
    
    //VERIFICAR SI UN DATO ES UN NUMERO TELÉFONICO
    public boolean isTelef(String cadena){
        Metodos_Varios metodos = new Metodos_Varios();
        if ((metodos.isNumeric(cadena)) & (cadena.length())>=9){
        return true;
        } else{
            return false;
        }
    }
    
    //OBTENER OBJETO DEL USUARIO QUE HA HECHO LOGIN
    public Usuario obtenerUser(ArrayList<Usuario> userInfo, String usuario){
        Usuario info = new Usuario("","","","");
        for(Usuario p: userInfo){
            if (usuario.equals(p.getUsuario())){
                info = p;
            }
        }
        return info;     
    }
    
    //OBTENER OBJETO DE UN CLIENTE
    public Cliente obtenerCliente(ArrayList<Cliente> clienteInfo, String cod){
        Cliente info = new Cliente("","","","","");
        for(Cliente p: clienteInfo){
            if (cod.equals(p.getCodigo())){
                info = p;
            }
        }
        return info;     
    }
    
    //GENERAR STR DEL MENÚ DE TECNICO
    public String obtenerMenuT(){
        String strMenu = "\t1. Información de Clientes\n" +
                         "\t2. Información de Proveedores\n" +
                         "\t3. Información de Países\n" +
                         "\t4. Administrar IPs\n" +
                         "\t5. Información de Tarifa de Región\n" +
                         "\t6. Facturar llamadas\n"+
                         "\t7. Salir";
        return strMenu;
    }
    
    //GENERAR STR DEL MENÚ DE ADMIN
    public String obtenerMenuA(){
        String strMenu = "\t1. Detalle Factura Cliente\n" +
                         "\t2. Reporte llamadas por Clientes por Mes\n" +
                         "\t3. Reporte llamadas por Proveedor por Mes\n"+
                         "\t4. Salir";
        return strMenu;
    }
    
    //IMPRIMIR DATOS DE UN CLIENTE
    public void imprimirCliente(ArrayList<Cliente> clienteInfo, String cod){
        Metodos_Varios metodos = new Metodos_Varios();
        Cliente cliente1 = metodos.obtenerCliente(clienteInfo, cod);
        System.out.println("\n\n\tNombre: "+cliente1.getNombre()+
            "\n\tDireccion: "+cliente1.getDireccion()+
            "\n\tTelefono: "+cliente1.getTelefono()+
            "\n\tTipo: "+cliente1.getTipo());
    }
    
    //IMPRIMIR DATOS DE TODOS LOS CLIENTES
    public void imprimirClientes(ArrayList<Cliente> clienteInfo){
        for (Cliente p: clienteInfo){
            System.out.println("\n"+p.getCodigo()+"\tNombre: "+p.getNombre()+
            "\tDireccion: "+p.getDireccion()+ "\tTelefono: "+p.getTelefono()+
            "\tTipo: "+p.getTipo()+"\n--------------------------");
        }                
    }
    
    //VERIFICAR QUE UN CODIGO INGRESADO ESTÉ EN EL CSV
    public boolean verificarCod(ArrayList<Cliente> clienteInfo, String codigo){
        boolean verificacion= false;
        for(Cliente p: clienteInfo){
            if (codigo.equals(p.getCodigo())){
                verificacion = true;
                break;
            }else{
                verificacion = false;
            }
        }
        return verificacion;
    }
    
    //GENERAR STR DEL MENÚ DE EDICION DE CLIENTES
    public void menuClientes(){
        System.out.println("\n¿Qué sección desea editar?"
                + "\n\t1. Código\n\t2. Nombre\n\t3. Dirección"
                + "\n\t4. Teléfono\n\t5. Tipo de Cliente"
                + "\n\t6. Salir");
    }
    
    //MENÚ DE EDICION DE CLIENTES DESARROLLADO (MENU TECNICO OPCION 1)
    public void elegirdeClientes(ArrayList<Cliente> clienteInfo){
        int cont1 =0;int cont2 = 0;int cont3 = 0;Metodos_Varios metodos = new Metodos_Varios();
        while (cont1!=1){            
            System.out.println("\n¿Desea editar la Información de los Clientes? (Y/N)\n");
            String decision1 = entrada.next();
            if(decision1.equalsIgnoreCase("Y")){
                metodos.imprimirClientes(clienteInfo); cont2 = 0;
                while(cont2!=1){
                    System.out.println("\nIngrese el código del cliente que desea editar: \n");
                    String cod = entrada.next();
                    if(metodos.verificarCod(clienteInfo, cod)==true){ 
                        Cliente cliente1 = metodos.obtenerCliente(clienteInfo, cod);
                        metodos.imprimirCliente(clienteInfo, cod);                                                
                        metodos.menuClientes();
                        String decision2 = entrada.next();
                        Scanner entrada2 = new Scanner(System.in);
                        switch (decision2){
                            case "1":  
                                System.out.println("\nEscriba un nuevo código para su Cliente: \n");
                                String newCod= entrada.next();                
                                if (metodos.isNumeric(newCod)){
                                    cliente1.setCodigo(newCod);
                                    metodos.imprimirClientes(clienteInfo);
                                }else{
                                    System.out.println("Código No Válido");
                                }                                
                                cont2 = 1;
                                break;
                                
                            case "2":
                                System.out.println("\nEscriba un nuevo Nombre para su Cliente: ");
                                String newName= entrada2.nextLine(); 
                                cliente1.setNombre(newName);
                                metodos.imprimirClientes(clienteInfo);
                                cont2 = 1;
                                break;
                                
                            case "3":
                                System.out.println("\nEscriba una nueva Dirección para su Cliente: \n");
                                String newDirecc= entrada2.nextLine(); 
                                cliente1.setDireccion(newDirecc);
                                metodos.imprimirClientes(clienteInfo);
                                cont2 = 1;
                                break;
                                
                            case "4":
                                System.out.println("\nEscriba un nuevo Número de Teléfono para su Cliente: \n");
                                String newTel= entrada.next(); 
                                //verificar que sea numero mayor o igual a 10
                                if (metodos.isTelef(newTel)){
                                    cliente1.setTelefono(newTel);
                                    metodos.imprimirClientes(clienteInfo);
                                }else{
                                    System.out.println("Número No Válido");
                                }        
                                cont2 = 1;                               
                                break;
                            
                            case "5":
                                System.out.println("\nEscriba el nuevo Tipo de Cliente \n");
                                String newTipo= entrada.next();                
                                if (newTipo.equalsIgnoreCase("Wholesale")){
                                    cliente1.setTipo(newTipo);
                                    metodos.imprimirClientes(clienteInfo);
                                }else if(newTipo.equalsIgnoreCase("Retail")) {
                                    cliente1.setTipo(newTipo);
                                    metodos.imprimirClientes(clienteInfo);
                                }else{
                                    System.out.println("Ingreso no Válido");
                                } 
                                cont2 = 1;
                                break;
                                
                            case "6":
                                cont2 = 1;
                                break;
                                
                            default:
                                System.out.println("\nSelección Incorrecta");
                                cont2 = 1;
                                break;                           
                        }
                    }else{
                        System.out.println("Código No Válido");
                    }
                }
            }else if(decision1.equalsIgnoreCase("N")){
                cont1++;
            }else{
                System.out.println("\nEntrada Incorrecta\n");
            }         
        }         
    }
    
    //MENÚ DE EDICION DE PROVEEDORES DESARROLLADO
    
    //MENÚ DE EDICION DE PAISES DESARROLLADO
    
    //MENÚ DE EDICION DE IPS DESARROLLADO
    
    //MENÚ DE EDICION DE TARIFAS DESARROLLADO
    
    //FACTURAR LLAMADAS (MENU TECNICO OPCION 6)
    public void facturarLlamadas(ArrayList<Ip> ipInfo, ArrayList<Tarifa> tarifaInfo,ArrayList<Cliente> clienteInfo){
        ArrayList<Llamada> llamadaInfo = Lecturas.leerLlamada();
        ArrayList<Pais> paisInfo = Lecturas.leerPais();
        for(Llamada m: llamadaInfo){
            String codCliente="",codProvee="",codPais="", tipoC=""; 
            double costoCliente=0; double costoProvee=0; 
            String fecha = m.getFecha(); String hora = m.getHora();
            String ipF = m.getIpF(); String ipD = m.getIpD();
            String dnis = m.getDNIS(); String ani = m.getANI();
            String estado = m.getEstado(); String duracion = m.getDuracion();
            if (estado.equals("E")) {
                costoProvee = 0;costoCliente =0;              
            }
            for (Ip n: ipInfo){
                if (ipF.equals(n.getIp())) codCliente = n.getCodigo();  
                else if (ipD.equals(n.getIp())) codProvee = n.getCodigo();              
            }
            for (Tarifa p: tarifaInfo){
                if (dnis.startsWith(p.getPrefijoRegion())){
                    String prefPais = p.getPrefijoPais(); 
                    for (Pais q: paisInfo){
                        if (prefPais.equals(q.getPrefijo())) codPais = q.getCodigo();
                    }
                    if (!estado.equals("E")){
                        costoProvee = ((double)Float.parseFloat(duracion)/60)*Float.parseFloat(p.getTarifa());
                    }  
                    break;
                }
                else{
                    codPais = "NA"; costoProvee = 0; costoCliente =0;
                }
            } 
            for(Cliente q: clienteInfo){
                if (codCliente.equals(q.getCodigo())) tipoC = q.getTipo();                       
                if (tipoC.equalsIgnoreCase("Wholesale") & !estado.equals("E")){
                    costoCliente = (costoProvee+=((double)(costoProvee*5)/100));
                }
                else if(tipoC.equalsIgnoreCase("Retail")& !estado.equals("E")){
                    costoCliente =(costoProvee+=((double)(costoProvee*10)/100));
                }
            }  
            Lecturas.escribirLlamadas(fecha, hora, ipF, ipD, dnis, ani, duracion, codCliente, codProvee, codPais, costoCliente, costoProvee);
        } 
    }

    //GENERAR DETALLE DE FACTURA (ADMIN OPCION 1)
    public void mostrarFactura(ArrayList<Cliente> clienteInfo, ArrayList<Cliente> listClienteF, ArrayList<String> listMeses){        
        System.out.println("Ingrese el codigo del cliente que desea generar Factura: ");
        String codIngreso = entrada.next(); Metodos_Varios metodos = new Metodos_Varios();
        while(!metodos.verificarCod(clienteInfo, codIngreso)){
            System.out.println("\nCódigo Incorrecto");
            System.out.println("\nIngrese el codigo del cliente que desea generar Factura: ");
            codIngreso = entrada.next();
        }
        System.out.println("\nIngrese el mes que desea facturar (formato 2 digitos): ");                                 
        String mesStr = entrada.next();
        if (!listMeses.contains(mesStr)){
            System.out.println("\tError, Mes no Encontrado");
        }else{                                       
            for (Cliente m: listClienteF){
                String nombreCliente="", tipo=""; double totalLlamFact=0, totalCosto=0, totalPago=0; int cont3 =0,llamInte,llamComp;
                if (m.getCodigo().equals(codIngreso) & m.getMes().equals(mesStr)){
                    for(Cliente n: clienteInfo){
                        if(m.getCodigo().equals(n.getCodigo())){
                            nombreCliente= n.getNombre();
                            tipo = n.getTipo();
                            cont3++;
                        }
                    }
                }
                llamInte = m.getLlamInte(); llamComp = m.getLlamComp();
                totalLlamFact = m.getTotalPago();
                if (tipo.equals("Wholesale")){
                    totalCosto=20;                                            
                }else{
                    totalCosto=0;
                }
                totalPago=totalLlamFact+totalCosto;
                                            
                if (cont3!=0){
                    System.out.println("--------------------------");
                    System.out.println("\tCliente: "+nombreCliente);
                    System.out.println("\tLlamadas completadas:  "+llamComp);
                    System.out.println("\tIntentos de llamadas:  "+llamInte);                   
                    System.out.println("\tTotal llamadas facturadas: $ "+totalLlamFact);
                    System.out.println("\tTotal costo de servicio: $ "+totalCosto);
                    System.out.println("\tTotal a pagar en el mes: $ "+totalPago);
                    System.out.println("--------------------------");
                }                                            
            }                                      
        }
    }
    
    //REPORTE DE CUENTAS PRO MES (MENU ADMIN OPCION 2)
    public void mostrarReporteMesC(ArrayList<Cliente> clienteInfo, ArrayList<Cliente> listClienteF, ArrayList<String> listMeses,ArrayList<Pais> paisInfo){
        System.out.println("\nIngrese el mes que desea consultar (formato 2 digitos): ");                                 
        String mesStr = entrada.next();
        while (!listMeses.contains(mesStr)){
            System.out.println("\tError, Mes no Encontrado");
            System.out.println("\nIngrese el mes que desea consultar (formato 2 digitos): ");                                 
            mesStr = entrada.next();
        }
        for (Cliente m: listClienteF){
            String nombreCliente="", pais="", tipo=""; double totalLlamFact=0, 
            totalCosto=0, totalPago=0; int cont3 =0, llamInte =0, llamComp = 0;
            if (m.getMes().equals(mesStr)){
                for(Cliente n: clienteInfo){
                    if(m.getCodigo().equals(n.getCodigo())){                          
                        nombreCliente= n.getNombre();
                        tipo = n.getTipo();
                        cont3++;
                    }
                }
            }
            llamInte = m.getLlamInte(); llamComp = m.getLlamComp();
            for (Pais n: paisInfo){
                if (m.getCodPais().equals(n.getCodigo())){
                    pais = n.getNombre();
                }
            }
            totalLlamFact = m.getTotalPago();
            if (tipo.equals("Wholesale")){
                totalCosto=20;                                            
            }else{
                totalCosto=0;
            }
            totalPago=totalLlamFact+totalCosto;                               
            if (cont3!=0){
                System.out.println("------------------------------");
                System.out.println("\tNombre de Cliente: "+nombreCliente);
                System.out.println("\tPaís:  "+pais);
                System.out.println("\tLlamadas completadas:  "+llamComp);
                System.out.println("\tIntentos de llamadas:  "+llamInte);
                System.out.println("\tTotal a pagar en el mes: $ "+totalPago);
                System.out.println("------------------------------");
            }                                            
        }     
    }
    
    public void mostrarReporteMesP(ArrayList<Proveedor> proveedorInfo, ArrayList<Proveedor> listProveeF, ArrayList<String> listMeses,ArrayList<Pais> paisInfo){
        System.out.println("\nIngrese el mes que desea consultar (formato 2 digitos): ");                                 
        String mesStr = entrada.next();
        while (!listMeses.contains(mesStr)){
            System.out.println("\tError, Mes no Encontrado");
            System.out.println("\nIngrese el mes que desea consultar (formato 2 digitos): ");                                 
            mesStr = entrada.next();
        }
        for (Proveedor m: listProveeF){
            String nombreProvee="", pais="", tipo=""; double totalPago=0; 
            int cont3 =0, llamInte =0, llamComp = 0;
            if (m.getMes().equals(mesStr)){
                for(Proveedor n: proveedorInfo){
                    if(m.getCodigo().equals(n.getCodigo())){                          
                        nombreProvee= n.getNombre();
                        cont3++;
                    }
                }
            }
            llamInte = m.getLlamInte(); llamComp = m.getLlamComp();
            for (Pais n: paisInfo){
                if (m.getCodPais().equals(n.getCodigo())){
                    pais = n.getNombre();
                }
            }
            
            totalPago = m.getTotalPago();                                        
            if (cont3!=0){
                System.out.println("------------------------------");
                System.out.println("\tNombre de Proveedor: "+nombreProvee);
                System.out.println("\tPaís:  "+pais);
                System.out.println("\tLlamadas completadas:  "+llamComp);
                System.out.println("\tIntentos de llamadas:  "+llamInte);
                System.out.println("\tTotal a pagar en el mes: $ "+totalPago);
                System.out.println("------------------------------");
            }                                            
        }     
    }
}
