import Inicializacion.*;
import Metodos.*;
import java.io.File;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.util.Scanner;
public class Proyecto_PrimerP {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        //ARRAYS INICIALES DE INFORMACIÓN
        ArrayList<Usuario> userInfo = Lecturas.leerUsuario();
        ArrayList<Cliente> clienteInfo = Lecturas.leerCliente();
        ArrayList<Proveedor> proveedorInfo = Lecturas.leerProveedor();
        ArrayList<Pais> paisInfo = Lecturas.leerPais();
        ArrayList<Ip> ipInfo = Lecturas.leerIp();
        ArrayList<Tarifa> tarifaInfo = Lecturas.leerTarifa();
        /*for(Llamada p: llamadaInfo){
            System.out.println(p.getFecha());
            System.out.println(p.getDuracion());
            System.out.println(p.getHora());
            System.out.println(p.getIpF());
            System.out.println(p.getIpD());
            System.out.println(p.getDNIS());
            System.out.println(p.getANI());
            System.out.println(p.getEstado());
            System.out.println("-------------------");
        }*/
        
        //INICIAR SESION
        String usuario, contraseña; int cont = 0; 
        while (cont!=1){
            usuario = JOptionPane.showInputDialog(null, 
                "Ingrese su nombre de Usuario: ", "INICIO DE SESIÓN",3);
            contraseña = JOptionPane.showInputDialog(null, 
                    "Ingrese su contraseña: ", "INICIO DE SESIÓN",3);
            String opcion = ""; String menustr = "";
            Metodos_Varios method = new Metodos_Varios();
            boolean verificacion1 = method.verificarLogin(userInfo, usuario,contraseña);
            if (verificacion1 ==true){
                JOptionPane.showMessageDialog(null, 
                    "Inicio de Sesión Satisfactorio", "MENSAJE",JOptionPane.INFORMATION_MESSAGE);            
                String nivel = method.obtenerUser(userInfo, usuario).getNivel();
                if (nivel.equals("tecnico")){                   
                    //MENU DE TECNICO
                    menustr = method.obtenerMenuT();
                    while (!opcion.equals("7")){
                        System.out.println("-----------------------------------"
                                +"\nBIENVENIDO AL MENÚ TÉCNICO\n"+menustr);
                        System.out.println("Ingrese una opción: ");
                        opcion = entrada.next();
                        System.out.println("-----------------------------------");
                        switch (opcion) {
                            //1. INFORMACION DE CLIENTES
                            case "1":
                                System.out.println("\n1. INFORMACIÓN DE CLIENTES\n");                                                               
                                method.elegirdeClientes(clienteInfo);
                                break;

                            case "2":
                                
                                break;

                            case "3":
                                
                                break;

                            case "4": 
                                
                                break;

                            case "5":
                                
                                break;

                            case "6":                        
                                System.out.println("\n6. FACTURAR LLAMADAS\n");
                                method.facturarLlamadas(ipInfo,tarifaInfo,clienteInfo);
                                File f = new File("llamadas_facturadas.csv");
                                JOptionPane.showMessageDialog(null, 
                                "El Proceso de creación ha finalizado\n"
                                + "La ruta de su archivo es: "+f.getAbsolutePath(), 
                                "PROCESO COMPLETO",JOptionPane.INFORMATION_MESSAGE);
                                break;

                            case "7":
                                opcion = "7";                                
                                break;
                                
                            default:
                                System.out.println("Selección Incorrecta");
                                break;
                        }
                    }                                                                                               
                }
                else if (nivel.equals("admin")){
                    //MENU DE ADMIN                   
                    File f = new File("llamadas_facturadas.csv"); 
                    menustr = method.obtenerMenuA(); int cont2 = 0;
                    if (!f.exists()){
                        System.out.println("\nNo hay información de facturación\n"); 
                        cont2++;
                    }                 
                    while (cont2==0){
                        while (!opcion.equals("4")) {
                            System.out.println("-----------------------------------"
                                +"\nBIENVENIDO AL MENÚ ADMIN\n"+menustr);
                            //sumarios
                            ArrayList<Cliente> listClienteF = Lecturas.crearSumarioC();
                            ArrayList<Proveedor> listProveeF = Lecturas.crearSumarioP();
                            ArrayList<String> listMeses = Lecturas.obtenerMeses();
                            
                            System.out.println("Ingrese una opción: ");
                            opcion = entrada.next();                           
                            /*for(Cliente p: listClienteF){
                                System.out.println(p.getMes());
                                System.out.println(p.getAño());
                                System.out.println(p.getCodCliente());
                                System.out.println(p.getCodPais());
                                System.out.println(p.getLlamComp());
                                System.out.println(p.getLlamInte());
                                System.out.println(p.getTotalPago());
                                //System.out.println(p.());
                                System.out.println("-------------------");
                            }*/

                            switch (opcion) {
                                //1. INFORMACION DE CLIENTES
                                case "1":                                   
                                    System.out.println("\n1. DETALLE FACTURA DE CLIENTE\n");                                                               
                                    method.mostrarFactura(clienteInfo, listClienteF, listMeses);
                                    break;

                                case "2":
                                    System.out.println("\n2. ​ REPORTE LLAMADAS ​POR CUENTAS POR MES\n");                                                               
                                    method.mostrarReporteMesC(clienteInfo, listClienteF, listMeses,paisInfo);                
                                    break;

                                case "3":
                                    System.out.println("\n3. ​REPORTE LLAMADAS POR PROVEEDOR POR MES\n");
                                    method.mostrarReporteMesP(proveedorInfo, listProveeF, listMeses, paisInfo);
                                    break;

                                case "4": 
                                    opcion = "4";
                                    cont=0;
                                    cont2++;
                                    break;
                                    
                                default:
                                    System.out.println("Selección Incorrecta");
                                    break;
                            }                       
                        }
                    }                                     
                }
                else {
                    JOptionPane.showMessageDialog(null, 
                        "Usuario o contraseña no Válida ", "ERROR EN INICIO DE SESIÓN",JOptionPane.ERROR_MESSAGE);
                }
            }
        }      
    }
}