package Inicializacion;
public class Tarifa {
    private String codigoPro, prefijoPais, nombreRegion, prefijoRegion, tarifa;
    
    //constructor
    public Tarifa(String codigoPro, String prefijoPais, String nombreRegion, String prefijoRegion, String tarifa){
        this.codigoPro = codigoPro;
        this.prefijoPais = prefijoPais;
        this.nombreRegion = nombreRegion;
        this.prefijoRegion = prefijoRegion;
        this.tarifa = tarifa;
    }
    
    //setters
    public void setcodigoPro(String codigoPro){
        this.codigoPro = codigoPro;
    }   
    public void setPrefijoPais(String prefijoPais){
        this.prefijoPais = prefijoPais;
    }    
    public void setnombreRegion(String nombreRegion){
        this.nombreRegion = nombreRegion;
    }    
    public void setPrefijoRegion(String prefijoRegion){
        this.prefijoRegion = prefijoRegion;
    } 
    public void setTarifa(String tarifa){
        this.tarifa = tarifa;
    }
    
    //getters
    public String getcodigoPro(){
        return codigoPro;
    }   
    public String getPrefijoPais(){
        return prefijoPais;
    }    
    public String getnombreRegion(){
        return nombreRegion;
    }    
    public String getPrefijoRegion(){
        return prefijoRegion;
    } 
    public String getTarifa(){
        return tarifa;
    }
}
